Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/myhouse/
Buy theme: http://smthemes.com/buy/myhouse/
Support Forums: http://smthemes.com/support/forum/myhouse-free-wordpress-theme/