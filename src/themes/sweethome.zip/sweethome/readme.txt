Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/sweethome/
Buy theme: http://smthemes.com/buy/sweethome/
Support Forums: http://smthemes.com/support/forum/sweethome-free-wordpress-theme/