Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/building/
Buy theme: http://smthemes.com/buy/building/
Support Forums: http://smthemes.com/support/forum/building-free-wordpress-theme/