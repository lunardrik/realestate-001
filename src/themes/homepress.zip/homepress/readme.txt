Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/homepress/
Buy theme: http://smthemes.com/buy/homepress/
Support Forums: http://smthemes.com/support/forum/homepress-free-wordpress-theme/