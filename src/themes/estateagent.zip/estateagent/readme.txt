Theme Author: http://smthemes.com
Theme Homepage: http://smthemes.com/estateagent/
Buy theme: http://smthemes.com/buy/estateagent/
Support Forums: http://smthemes.com/support/forum/estateagent-free-wordpress-theme/