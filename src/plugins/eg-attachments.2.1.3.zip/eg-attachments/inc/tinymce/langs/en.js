tinyMCE.addI18n("en.ega_shortcode", {
	title: 'Insert or Edit Shortcode'
});