tinyMCE.addI18n("fr.ega_shortcode", {
	title: 'Inserer un raccourci EG-Attachments'
});